# ai-art-gallery

A curated collection of NSFW-friendly Stable Diffusion prompts, model links, and resources for realistic AI-generated swimsuit and boudoir art.

## 🧠 Recommended Models (Download via [Civitai](https://civitai.com))

### 📸 Realistic Photographic Models:
- [Realistic Vision v5.1](https://civitai.com/models/4201/realistic-vision-v51)
- [Deliberate](https://civitai.com/models/4823/deliberate)
- [ReV Animated](https://civitai.com/models/7371/rev-animated)

## 🎯 Prompt Examples

### 🩱 Swimsuit Glamour Shot
Stunning blonde woman in a tiny red bikini, wet skin, soft beach lighting, Canon 85mm lens, high resolution, detailed abs, seductive expression, glistening skin, standing in ocean waves

### 🛏️ Boudoir Indoor Studio
Lingerie model lying on silk sheets, warm softbox lighting, ambient glow, lace corset, alluring eyes, sensual pose, ultra-detailed skin texture, Canon 50mm lens

### ❌ Negative Prompt
bad anatomy, blurry, lowres, extra limbs, text, watermark, deformed hands, ugly, mutated

## 🧩 How to Use These
1. Install [AUTOMATIC1111 WebUI](https://github.com/AUTOMATIC1111/stable-diffusion-webui)
2. Add the above models to `/models/Stable-diffusion/`
3. Copy prompts into the "txt2img" tab
4. Tweak until perfect — change lighting, poses, outfit

> 💡 Contribute your best prompts or models by submitting a pull request!